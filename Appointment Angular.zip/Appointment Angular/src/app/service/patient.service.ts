import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Appointment } from '../model/appointment.mode';
import { Doctor } from '../model/doctor.model';
import { Slots } from '../model/slots.model';

@Injectable({
  providedIn: 'root'
})
export class PatientService {

  constructor(private http:HttpClient) { }
  allDoctors():Observable<Doctor[]>{
    return this.http.get<Doctor[]>('http://localhost:9016/all/doctors');
  }

  allSlots():Observable<Slots[]>{
    return this.http.get<Slots[]>('http://localhost:9016/all/slots');
  }

  bookAppointment(appointment:Appointment):Observable<Appointment>{
     return this.http.post<Appointment>('http://localhost:9016/book/appointment',appointment);
  }

getDoctorInfo(doctorId: string) :Observable<Doctor>{
     return this.http.get<Doctor>('http://localhost:9016/doctor/' + doctorId);
  }

  getSlotInfo(slotId: string) :Observable<Slots>{
    return this.http.get<Slots>('http://localhost:9016/slot/' + slotId);

  }

  getAllAppointment(): Observable<Appointment[]>{
    return this.http.get<Appointment[]>('http://localhost:9016/get/all/appointment');
  }
}
