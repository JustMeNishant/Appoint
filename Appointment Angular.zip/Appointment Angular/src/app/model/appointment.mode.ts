export class Appointment{
    name:string;
    contact:string;
    doctorId:number;
    slotId:number;
    apptDate:string;
}