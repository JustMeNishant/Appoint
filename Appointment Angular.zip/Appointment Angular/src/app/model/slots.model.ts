import { Doctor } from "./doctor.model";

export class Slots{
    id?:number;
    time:string;
  doctor: Doctor
}