export class Doctor{
    id?:number;
    name:string;
    speciality:string;
}